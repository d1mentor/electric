$(document).ready(function() {
    $('.burger-icon').click(function(){
        $('.nav-item-list').toggleClass('show');
    });
});